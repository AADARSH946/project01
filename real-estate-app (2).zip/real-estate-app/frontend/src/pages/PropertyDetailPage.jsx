import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine
} from "recharts";
import { motion } from "framer-motion";
import { Building2, GraduationCap, Hospital, Route as RouteIcon } from "lucide-react";
import { fetchPropertyDetail } from "../api.js";
import { formatINR, formatNumber } from "../utils/format.js";
import StampBadge from "../components/StampBadge.jsx";

function InfoList({ title, icon, items, renderExtra }) {
  if (!items || items.length === 0) return null;
  return (
    <div className="bg-white rounded-xl border border-blueprint-100 p-5">
      <h3 className="font-display text-lg mb-3 flex items-center gap-2">
        <span>{icon}</span> {title}
      </h3>
      <ul className="space-y-2">
        {items.map((item, i) => (
          <li
            key={i}
            className="flex items-center justify-between text-sm border-b border-blueprint-100/70 last:border-0 pb-2 last:pb-0"
          >
            <span className="text-blueprint-950">{item.name}</span>
            <span className="text-blueprint-700 font-mono text-xs flex items-center gap-2">
              {renderExtra ? renderExtra(item) : null}
              {item.distanceKm} km
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload || !payload.length) return null;
  const d = payload[0].payload;
  return (
    <div className="bg-blueprint-900 text-paper text-xs rounded-lg px-3 py-2 shadow-lg">
      <p className="font-semibold mb-1">{label}</p>
      <p className="font-mono">{formatINR(d.projectedValue)}</p>
      <p className="text-brass-400">+{d.profitPct}% from today</p>
    </div>
  );
}

export default function PropertyDetailPage() {
  const { id } = useParams();
  const [property, setProperty] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchPropertyDetail(id)
      .then(setProperty)
      .catch(() => setError("Could not load this property. Is the backend running?"));
  }, [id]);

  if (error) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-20 text-center">
        <p className="text-clay">{error}</p>
        <Link to="/" className="text-blueprint-700 underline mt-4 inline-block">
          Back to search
        </Link>
      </div>
    );
  }

  if (!property) {
    return <div className="max-w-3xl mx-auto px-6 py-20 text-center text-blueprint-700">Loading…</div>;
  }

  const chartData = property.profitProjection.map((p) => ({
    year: p.year,
    projectedValue: p.projectedValue,
    profitPct: p.profitPct
  }));

  const rec = property.sellRecommendation;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <Link to="/" className="text-sm text-blueprint-700 hover:text-blueprint-900">
        ← Back to search
      </Link>

      {/* Header */}
      <div className="mt-4 grid lg:grid-cols-[1.2fr_1fr] gap-8 items-start">
        <div className="relative">
          <img
            src={property.image}
            alt={property.title}
            className="w-full h-72 object-cover rounded-2xl"
          />
          {property.source === "kaggle" && (
            <>
              <div
                className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none select-none rounded-2xl"
                aria-hidden="true"
              >
                <span className="-rotate-[28deg] whitespace-nowrap text-white/25 text-sm font-bold tracking-[0.35em] uppercase">
                  Kaggle &nbsp;&nbsp;&nbsp; Kaggle &nbsp;&nbsp;&nbsp; Kaggle &nbsp;&nbsp;&nbsp; Kaggle
                </span>
              </div>
              <span className="absolute top-3 right-3 bg-slate-700/90 text-paper text-xs font-semibold px-3 py-1 rounded-full">
                Kaggle Dataset
              </span>
            </>
          )}
        </div>
        <div className="flex flex-col gap-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl leading-tight">{property.title}</h1>
              <p className="text-blueprint-700 mt-1">{property.address}</p>
            </div>
            <StampBadge value={property.appreciationRate} label="CAGR" />
          </div>
          {property.source === "kaggle" && (
            <p className="text-xs text-blueprint-700/70 -mt-2">
              Base listing data adapted from{" "}
              <span className="font-medium">{property.sourceDataset || "a public Kaggle dataset"}</span>.
              Appreciation rate and nearby-infrastructure details are supplemented, as the original
              dataset doesn't include them.
            </p>
          )}

          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-blueprint-700">
            <span>{property.type}</span>
            <span>{property.bhk} BHK</span>
            <span>{formatNumber(property.sizeSqft)} sqft</span>
            <span>₹{formatNumber(property.pricePerSqft)}/sqft</span>
            <span>{property.status}</span>
          </div>

          <div className="font-mono text-3xl font-semibold text-blueprint-950">
            {formatINR(property.price)}
          </div>

          <div className="flex flex-wrap gap-2">
            {property.amenities.map((a) => (
              <span
                key={a}
                className="text-xs bg-blueprint-100 text-blueprint-800 rounded-full px-3 py-1"
              >
                {a}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Sell recommendation banner */}
      <div className="mt-10 bg-blueprint-900 text-paper rounded-2xl p-6 sm:p-8 grid sm:grid-cols-[auto_1fr] gap-6 items-center">
        <div className="text-center sm:text-left">
          <p className="font-mono text-brass-400 text-xs uppercase tracking-widest">
            Suggested sell year
          </p>
          <p className="font-display text-5xl mt-1">{rec.suggestedYear}</p>
          <p className="text-sm text-blueprint-100 mt-1">
            ~{rec.holdYears} year hold from today
          </p>
        </div>
        <div>
          <p className="text-sm leading-relaxed text-blueprint-100">{rec.reason}</p>
          <div className="flex gap-6 mt-4 font-mono">
            <div>
              <p className="text-xs text-blueprint-100/70">Est. value</p>
              <p className="text-lg text-brass-400">{formatINR(rec.estimatedValue)}</p>
            </div>
            <div>
              <p className="text-xs text-blueprint-100/70">Est. profit</p>
              <p className="text-lg text-brass-400">
                {formatINR(rec.estimatedProfit)} (+{rec.estimatedProfitPct}%)
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="mt-10 bg-white rounded-2xl border border-blueprint-100 p-5 sm:p-8">
        <h2 className="font-display text-xl mb-1">10-year value projection</h2>
        <p className="text-sm text-blueprint-700 mb-5">
          Estimated using locality appreciation rate plus nearby infrastructure
          boosts. Illustrative, not a guarantee.
        </p>
        <ResponsiveContainer width="100%" height={320}>
          <LineChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E7EEF2" />
            <XAxis dataKey="year" tick={{ fontSize: 12 }} />
            <YAxis
              tickFormatter={(v) => `₹${(v / 10000000).toFixed(1)}Cr`}
              tick={{ fontSize: 12 }}
              width={70}
            />
            <Tooltip content={<CustomTooltip />} />
            <ReferenceLine
              x={rec.suggestedYear}
              stroke="#C9A227"
              strokeDasharray="4 4"
              label={{ value: "Suggested sell", position: "top", fontSize: 11, fill: "#A9821A" }}
            />
            <Line
              type="monotone"
              dataKey="projectedValue"
              stroke="#204C69"
              strokeWidth={2.5}
              dot={{ r: 3 }}
              activeDot={{ r: 5 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Nearby everything */}
      <div className="mt-10">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-5">
          <h2 className="font-display text-2xl">What's growing around it</h2>
          {property.nearbyDataMatchType === "city-wide" && (
            <span className="text-xs bg-brass-500/15 text-brass-600 rounded-full px-3 py-1">
              Approximate — based on city-wide data
            </span>
          )}
          {property.nearbyDataMatchType === "none" && (
            <span className="text-xs bg-clay/15 text-clay rounded-full px-3 py-1">
              No nearby data available for this location yet
            </span>
          )}
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <InfoList
            title="Upcoming Projects"
            icon={<Building2 size={17} className="text-blueprint-700" />}
            items={property.nearbyProjects}
            renderExtra={(item) => (
              <span className="text-blueprint-500">{item.completionYear} ·</span>
            )}
          />
          <InfoList
            title="Hospitals"
            icon={<Hospital size={17} className="text-blueprint-700" />}
            items={property.hospitals}
          />
          <InfoList
            title="Schools"
            icon={<GraduationCap size={17} className="text-blueprint-700" />}
            items={property.schools}
          />
          <InfoList
            title="Road Connectivity"
            icon={<RouteIcon size={17} className="text-blueprint-700" />}
            items={property.roadConnectivity}
          />
        </div>
      </div>

      <p className="text-xs text-blueprint-700/70 mt-10 border-t border-blueprint-100 pt-4">
        Disclaimer: All figures are generated by a simplified, rule-based model
        for demonstration purposes using sample data. They are not financial
        advice and should not be the sole basis for a real investment
        decision — verify current prices, RERA registration, and local trends
        independently before buying.
      </p>
    </div>
  );
}
