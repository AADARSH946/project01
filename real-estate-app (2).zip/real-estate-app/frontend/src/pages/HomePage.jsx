import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { MapPinned, TrendingUp, CalendarClock, ArrowRight } from "lucide-react";
import SearchForm from "../components/SearchForm.jsx";
import PropertyCard from "../components/PropertyCard.jsx";
import PropertyCardSkeleton from "../components/PropertyCardSkeleton.jsx";
import { fetchMeta, searchProperties } from "../api.js";

export default function HomePage() {
  const [meta, setMeta] = useState(null);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMeta()
      .then(setMeta)
      .catch(() =>
        setError(
          "Could not reach the backend. Make sure it's running on http://localhost:5000."
        )
      );
  }, []);

  async function handleSearch(filters) {
    setLoading(true);
    setError("");
    setHasSearched(true);
    try {
      const data = await searchProperties(filters);
      setResults(data.results);
    } catch (err) {
      setError("Search failed. Is the backend server running?");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      {/* Hero */}
      <section className="blueprint-bg text-paper relative overflow-hidden">
        <div className="max-w-6xl mx-auto px-6 pt-16 sm:pt-20 pb-28 relative z-10">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="font-mono text-brass-400 text-sm tracking-widest uppercase mb-4"
          >
            Bhoomi · A New Era of Investing &amp; Selling
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="font-display text-4xl sm:text-5xl md:text-6xl leading-[1.05] max-w-3xl"
          >
            Find the flat. Read the future.
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-5 max-w-xl text-blueprint-100 text-base sm:text-lg"
          >
            Search real properties by city, locality and budget — then see a
            transparent, formula-based estimate of future value, the best
            year to sell, and everything growing around it: metros,
            highways, hospitals and schools.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.25 }}
            className="mt-6"
          >
            <Link
              to="/list-property"
              className="inline-flex items-center gap-2 text-sm font-semibold text-brass-400 hover:text-brass-300 border-b border-brass-400/40 hover:border-brass-300 pb-0.5 transition-colors"
            >
              Have a property to sell? List it and see its growth story
              <ArrowRight size={15} />
            </Link>
          </motion.div>
        </div>

        {/* Decorative growth line motif */}
        <svg
          className="absolute bottom-0 left-0 w-full h-28 opacity-70 float-slow"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <polyline
            points="0,100 150,90 300,95 450,60 600,70 750,35 900,45 1050,10 1200,20"
            fill="none"
            stroke="#D9B65B"
            strokeWidth="2.5"
          />
        </svg>
      </section>

      {/* Search form, overlapping hero */}
      <section className="max-w-6xl mx-auto px-6 -mt-14 relative z-20">
        <SearchForm meta={meta} onSearch={handleSearch} loading={loading} />
      </section>

      {/* Results */}
      <section className="max-w-6xl mx-auto px-6 py-14">
        {error && (
          <p className="text-clay bg-clay/10 border border-clay/30 rounded-lg px-4 py-3 text-sm mb-6">
            {error}
          </p>
        )}

        {!hasSearched && !loading && !error && (
          <div className="text-center py-16 text-blueprint-700">
            <p className="font-display text-2xl mb-2">
              Set your city and budget above to begin.
            </p>
            <p className="text-sm">
              Every result comes with a 5-year profit estimate at a glance.
            </p>
          </div>
        )}

        {loading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <PropertyCardSkeleton key={i} />
            ))}
          </div>
        )}

        {hasSearched && !loading && results.length === 0 && !error && (
          <p className="text-center py-16 text-blueprint-700 font-display text-xl">
            No properties matched those filters — try widening your budget or
            clearing the locality.
          </p>
        )}

        {!loading && results.length > 0 && (
          <>
            <div className="flex items-baseline justify-between mb-6">
              <h2 className="font-display text-2xl">
                {results.length} propert{results.length === 1 ? "y" : "ies"} found
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          </>
        )}
      </section>

      {/* How it works */}
      <section id="how-it-works" className="bg-blueprint-900 text-paper py-16 mt-10">
        <div className="max-w-6xl mx-auto px-6 grid sm:grid-cols-3 gap-10">
          <div>
            <MapPinned className="text-brass-400 mb-3" size={22} />
            <h3 className="font-display text-xl mb-2">Locality baseline</h3>
            <p className="text-sm text-blueprint-100">
              Each listing carries a historical appreciation rate for its
              locality — the starting point for every projection.
            </p>
          </div>
          <div>
            <TrendingUp className="text-brass-400 mb-3" size={22} />
            <h3 className="font-display text-xl mb-2">Infrastructure boost</h3>
            <p className="text-sm text-blueprint-100">
              Nearby metros, highways, IT parks and airports add a temporary
              boost around their completion year, weighted by distance.
            </p>
          </div>
          <div>
            <CalendarClock className="text-brass-400 mb-3" size={22} />
            <h3 className="font-display text-xl mb-2">Sell-year estimate</h3>
            <p className="text-sm text-blueprint-100">
              We flag the year after the last major catalyst finishes
              re-pricing demand — a reasoned estimate, not a guarantee.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
