import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Hospital, GraduationCap, Route, Construction, Sparkles } from "lucide-react";
import { fetchMeta, fetchAreaProfile, createProperty } from "../api.js";

const EMPTY_FORM = {
  title: "",
  city: "",
  area: "",
  address: "",
  type: "Apartment",
  bhk: 2,
  sizeSqft: "",
  price: "",
  status: "Ready to Move",
  image: "",
  amenities: "",
  appreciationRate: ""
};

function PreviewList({ icon, title, items, empty }) {
  return (
    <div>
      <h4 className="flex items-center gap-1.5 text-sm font-semibold text-blueprint-900 mb-2">
        {icon} {title}
      </h4>
      {items && items.length > 0 ? (
        <ul className="space-y-1.5">
          {items.map((item, i) => (
            <li key={i} className="text-xs text-blueprint-700 flex justify-between border-b border-blueprint-100 pb-1.5 last:border-0">
              <span>{item.name}</span>
              <span className="font-mono">{item.distanceKm} km</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-xs text-blueprint-700/60 italic">{empty}</p>
      )}
    </div>
  );
}

export default function ListPropertyPage() {
  const navigate = useNavigate();
  const [meta, setMeta] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [customCity, setCustomCity] = useState(false);
  const [customArea, setCustomArea] = useState(false);
  const [preview, setPreview] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchMeta().then(setMeta).catch(() => {});
  }, []);

  useEffect(() => {
    if (!form.city) {
      setPreview(null);
      return;
    }
    setPreviewLoading(true);
    const t = setTimeout(() => {
      fetchAreaProfile(form.city, form.area)
        .then(setPreview)
        .catch(() => setPreview(null))
        .finally(() => setPreviewLoading(false));
    }, 400);
    return () => clearTimeout(t);
  }, [form.city, form.area]);

  const areas = form.city && meta?.areasByCity ? meta.areasByCity[form.city] || [] : [];

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    if (!form.title || !form.city || !form.area || !form.sizeSqft || !form.price) {
      setError("Please fill in title, city, area, size and price.");
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        ...form,
        bhk: Number(form.bhk),
        sizeSqft: Number(form.sizeSqft),
        price: Number(form.price),
        appreciationRate: form.appreciationRate ? Number(form.appreciationRate) : undefined,
        amenities: form.amenities
          ? form.amenities.split(",").map((a) => a.trim()).filter(Boolean)
          : []
      };
      const created = await createProperty(payload);
      navigate(`/property/${created.id}`);
    } catch (err) {
      setError(err.message || "Something went wrong while listing your property.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-12">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <p className="font-mono text-brass-600 text-xs uppercase tracking-widest mb-2">List a property</p>
        <h1 className="font-display text-3xl sm:text-4xl mb-2">Add your property to Bhoomi</h1>
        <p className="text-blueprint-700 max-w-2xl">
          Tell us about the property. We'll automatically attach nearby
          infrastructure — upcoming projects, hospitals, schools and roads —
          based on properties we already know in that locality, and generate
          a 10-year value projection.
        </p>
      </motion.div>

      <div className="mt-8 grid lg:grid-cols-[1.3fr_1fr] gap-8 items-start">
        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl border border-blueprint-100 shadow-sm p-6 sm:p-8 flex flex-col gap-5"
        >
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
              Property title
            </label>
            <input
              value={form.title}
              onChange={(e) => update("title", e.target.value)}
              placeholder="e.g. Spacious 3BHK near South Bopal Circle"
              className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                City
              </label>
              {!customCity ? (
                <select
                  value={form.city}
                  onChange={(e) => {
                    if (e.target.value === "__other__") {
                      setCustomCity(true);
                      update("city", "");
                    } else {
                      update("city", e.target.value);
                    }
                    update("area", "");
                  }}
                  className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
                >
                  <option value="">Select city</option>
                  {meta?.cities?.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                  <option value="__other__">Other (type manually)</option>
                </select>
              ) : (
                <input
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                  placeholder="Type city name"
                  className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
                />
              )}
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Area / Locality
              </label>
              {!customArea && areas.length > 0 ? (
                <select
                  value={form.area}
                  onChange={(e) => {
                    if (e.target.value === "__other__") {
                      setCustomArea(true);
                      update("area", "");
                    } else {
                      update("area", e.target.value);
                    }
                  }}
                  className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
                >
                  <option value="">Select area</option>
                  {areas.map((a) => (
                    <option key={a} value={a}>
                      {a}
                    </option>
                  ))}
                  <option value="__other__">Other (type manually)</option>
                </select>
              ) : (
                <input
                  value={form.area}
                  onChange={(e) => update("area", e.target.value)}
                  placeholder="Type locality name"
                  className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
                />
              )}
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
              Full address (optional)
            </label>
            <input
              value={form.address}
              onChange={(e) => update("address", e.target.value)}
              placeholder="Street, landmark"
              className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Type
              </label>
              <select
                value={form.type}
                onChange={(e) => update("type", e.target.value)}
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              >
                <option>Apartment</option>
                <option>Villa</option>
                <option>Plot</option>
                <option>Independent House</option>
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                BHK
              </label>
              <select
                value={form.bhk}
                onChange={(e) => update("bhk", e.target.value)}
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n} BHK
                  </option>
                ))}
              </select>
            </div>
            <div className="flex flex-col gap-1.5 col-span-2 sm:col-span-1">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Size (sqft)
              </label>
              <input
                type="number"
                min="100"
                value={form.sizeSqft}
                onChange={(e) => update("sizeSqft", e.target.value)}
                placeholder="1500"
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Status
              </label>
              <select
                value={form.status}
                onChange={(e) => update("status", e.target.value)}
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              >
                <option>Ready to Move</option>
                <option>Under Construction</option>
              </select>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Asking price (₹)
              </label>
              <input
                type="number"
                min="100000"
                value={form.price}
                onChange={(e) => update("price", e.target.value)}
                placeholder="8500000"
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
                Annual appreciation % (optional)
              </label>
              <input
                type="number"
                step="0.1"
                value={form.appreciationRate}
                onChange={(e) => update("appreciationRate", e.target.value)}
                placeholder={
                  preview?.suggestedAppreciationRate
                    ? `Suggested: ${preview.suggestedAppreciationRate}%`
                    : "Auto-estimated if left blank"
                }
                className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
              />
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
              Image URL (optional)
            </label>
            <input
              value={form.image}
              onChange={(e) => update("image", e.target.value)}
              placeholder="https://…"
              className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
              Amenities (comma separated)
            </label>
            <input
              value={form.amenities}
              onChange={(e) => update("amenities", e.target.value)}
              placeholder="Clubhouse, Gym, Swimming Pool"
              className="rounded-lg border border-blueprint-100 px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500"
            />
          </div>

          {error && (
            <p className="text-clay bg-clay/10 border border-clay/30 rounded-lg px-4 py-2.5 text-sm">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="mt-2 bg-blueprint-900 hover:bg-blueprint-800 text-paper font-semibold rounded-lg py-3 transition-colors disabled:opacity-60"
          >
            {submitting ? "Listing…" : "List property & see projection"}
          </button>
        </form>

        {/* Live preview panel */}
        <div className="lg:sticky lg:top-24 bg-blueprint-900 text-paper rounded-2xl p-6 flex flex-col gap-5">
          <div className="flex items-center gap-2">
            <Sparkles size={18} className="text-brass-400" />
            <h3 className="font-display text-lg">What we already know nearby</h3>
          </div>

          {!form.city && (
            <p className="text-sm text-blueprint-100/70">
              Pick a city (and locality, if you know it) to see nearby
              infrastructure we'll attach to your listing automatically.
            </p>
          )}

          {form.city && previewLoading && (
            <p className="text-sm text-blueprint-100/70">Looking up locality data…</p>
          )}

          {form.city && !previewLoading && preview && (
            <>
              {preview.matchType === "none" && (
                <p className="text-xs text-brass-400">
                  No data for this location yet — your listing will still be
                  created, just without nearby infrastructure details.
                </p>
              )}
              {preview.matchType === "city-wide" && (
                <p className="text-xs text-brass-400">
                  No exact match for this locality — showing city-wide
                  infrastructure as an approximation.
                </p>
              )}
              <div className="bg-paper text-blueprint-950 rounded-xl p-4 flex flex-col gap-4">
                <PreviewList
                  icon={<Construction size={15} className="text-blueprint-700" />}
                  title="Upcoming projects"
                  items={preview.nearbyProjects}
                  empty="None found nearby."
                />
                <PreviewList
                  icon={<Hospital size={15} className="text-blueprint-700" />}
                  title="Hospitals"
                  items={preview.hospitals}
                  empty="None found nearby."
                />
                <PreviewList
                  icon={<GraduationCap size={15} className="text-blueprint-700" />}
                  title="Schools"
                  items={preview.schools}
                  empty="None found nearby."
                />
                <PreviewList
                  icon={<Route size={15} className="text-blueprint-700" />}
                  title="Road connectivity"
                  items={preview.roadConnectivity}
                  empty="None found nearby."
                />
              </div>
              {preview.suggestedAppreciationRate && (
                <p className="text-xs text-blueprint-100/80">
                  Suggested appreciation rate for {form.city}:{" "}
                  <span className="text-brass-400 font-mono">
                    {preview.suggestedAppreciationRate}%
                  </span>{" "}
                  — used automatically if you leave that field blank.
                </p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
