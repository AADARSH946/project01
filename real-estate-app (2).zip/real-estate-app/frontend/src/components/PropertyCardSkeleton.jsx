export default function PropertyCardSkeleton() {
  return (
    <div className="bg-white rounded-xl border border-blueprint-100 overflow-hidden shadow-sm">
      <div className="h-44 skeleton" />
      <div className="p-4 pt-7 flex flex-col gap-3">
        <div className="h-4 w-3/4 rounded skeleton" />
        <div className="h-3 w-1/2 rounded skeleton" />
        <div className="h-5 w-2/3 rounded skeleton mt-1" />
        <div className="h-3 w-full rounded skeleton mt-3" />
      </div>
    </div>
  );
}
