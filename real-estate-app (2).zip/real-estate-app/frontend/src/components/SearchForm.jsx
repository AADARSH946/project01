import { useEffect, useState } from "react";
import { MapPin, Building2, Home, Search } from "lucide-react";

export default function SearchForm({ meta, onSearch, loading }) {
  const [city, setCity] = useState("");
  const [area, setArea] = useState("");
  const [type, setType] = useState("");
  const [bhk, setBhk] = useState("");
  const [budget, setBudget] = useState([1000000, 35000000]);

  const areas = city && meta?.areasByCity ? meta.areasByCity[city] || [] : [];

  useEffect(() => {
    setArea("");
  }, [city]);

  function handleSubmit(e) {
    e.preventDefault();
    onSearch({
      city,
      area,
      type,
      bhk,
      minBudget: budget[0],
      maxBudget: budget[1]
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-paper/95 rounded-2xl shadow-2xl shadow-blueprint-950/20 border border-blueprint-100 p-5 sm:p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end"
    >
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700 flex items-center gap-1.5">
          <MapPin size={13} /> City
        </label>
        <select
          value={city}
          onChange={(e) => setCity(e.target.value)}
          className="rounded-lg border border-blueprint-100 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500 transition-shadow"
        >
          <option value="">All cities</option>
          {meta?.cities?.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700 flex items-center gap-1.5">
          <Building2 size={13} /> Area / Locality
        </label>
        <select
          value={area}
          onChange={(e) => setArea(e.target.value)}
          disabled={!city}
          className="rounded-lg border border-blueprint-100 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500 disabled:bg-blueprint-100/40 disabled:text-blueprint-700/50 transition-shadow"
        >
          <option value="">{city ? "All areas" : "Select a city first"}</option>
          {areas.map((a) => (
            <option key={a} value={a}>
              {a}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700 flex items-center gap-1.5">
          <Home size={13} /> Type
        </label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
          className="rounded-lg border border-blueprint-100 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500 transition-shadow"
        >
          <option value="">Any</option>
          {meta?.propertyTypes?.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
          BHK
        </label>
        <select
          value={bhk}
          onChange={(e) => setBhk(e.target.value)}
          className="rounded-lg border border-blueprint-100 bg-white px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brass-500 transition-shadow"
        >
          <option value="">Any</option>
          {[1, 2, 3, 4].map((n) => (
            <option key={n} value={n}>
              {n} BHK
            </option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5 lg:col-span-1">
        <label className="text-xs font-semibold uppercase tracking-wide text-blueprint-700">
          Max Budget: ₹{(budget[1] / 100000).toFixed(0)}L
        </label>
        <input
          type="range"
          min="1000000"
          max="35000000"
          step="500000"
          value={budget[1]}
          onChange={(e) => setBudget([budget[0], Number(e.target.value)])}
          className="accent-brass-500"
        />
        <button
          type="submit"
          disabled={loading}
          className="mt-1 flex items-center justify-center gap-2 bg-blueprint-900 hover:bg-blueprint-800 text-paper text-sm font-semibold rounded-lg py-2.5 transition-all hover:shadow-lg disabled:opacity-60"
        >
          <Search size={15} />
          {loading ? "Searching…" : "Find Properties"}
        </button>
      </div>
    </form>
  );
}
