export default function StampBadge({ value, label = "CAGR", size = "md" }) {
  const dims = size === "sm" ? "w-14 h-14 text-[10px]" : "w-20 h-20 text-xs";
  return (
    <div
      className={`stamp ${dims} shrink-0 rounded-full border-2 border-dashed border-brass-500 flex flex-col items-center justify-center bg-paper/90 text-blueprint-900 shadow-sm`}
      title={`Estimated ${label}`}
    >
      <span className="font-mono font-semibold leading-none">{value}%</span>
      <span className="uppercase tracking-wider text-blueprint-700 font-body mt-0.5" style={{ fontSize: "8px" }}>
        {label}
      </span>
    </div>
  );
}
