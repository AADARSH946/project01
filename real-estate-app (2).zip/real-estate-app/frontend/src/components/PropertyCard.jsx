import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { BedDouble, Ruler, TrendingUp } from "lucide-react";
import { formatINR } from "../utils/format.js";
import StampBadge from "./StampBadge.jsx";

export default function PropertyCard({ property }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
    >
      <Link
        to={`/property/${property.id}`}
        className="group bg-white rounded-xl border border-blueprint-100 overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full"
      >
        <div className="relative h-44 overflow-hidden">
          <img
            src={property.image}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-blueprint-950/40 via-transparent to-transparent" />
          {property.source === "kaggle" && (
            <div
              className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none select-none"
              aria-hidden="true"
            >
              <span className="-rotate-[28deg] whitespace-nowrap text-white/25 text-[11px] font-bold tracking-[0.35em] uppercase">
                Kaggle &nbsp;&nbsp;&nbsp; Kaggle &nbsp;&nbsp;&nbsp; Kaggle
              </span>
            </div>
          )}
          <span className="absolute top-3 left-3 bg-blueprint-900/90 text-paper text-[11px] font-semibold px-2.5 py-1 rounded-full">
            {property.status}
          </span>
          {property.userListed && (
            <span className="absolute top-3 right-3 bg-brass-500 text-blueprint-950 text-[11px] font-semibold px-2.5 py-1 rounded-full">
              User Listed
            </span>
          )}
          {property.source === "kaggle" && (
            <span className="absolute top-3 right-3 bg-slate-700/90 text-paper text-[11px] font-semibold px-2.5 py-1 rounded-full">
              Kaggle Dataset
            </span>
          )}
          <div className="absolute -bottom-6 right-3">
            <StampBadge value={property.appreciationRate} label="CAGR" size="sm" />
          </div>
        </div>

        <div className="p-4 pt-7 flex flex-col gap-2 flex-1">
          <h3 className="font-display text-lg leading-snug text-blueprint-950 group-hover:text-blueprint-700 transition-colors">
            {property.title}
          </h3>
          <p className="text-sm text-blueprint-700">
            {property.area}, {property.city}
          </p>

          <div className="flex items-baseline gap-2 mt-1">
            <span className="font-mono font-semibold text-lg text-blueprint-900">
              {formatINR(property.price)}
            </span>
          </div>

          <div className="flex items-center gap-4 text-xs text-blueprint-700">
            <span className="flex items-center gap-1">
              <BedDouble size={14} /> {property.bhk} BHK
            </span>
            <span className="flex items-center gap-1">
              <Ruler size={14} /> {property.sizeSqft} sqft
            </span>
          </div>

          <div className="mt-auto pt-3 border-t border-blueprint-100 flex items-center justify-between text-sm">
            <span className="text-blueprint-700">By {property.quickProjection.year}</span>
            <span className="font-mono font-semibold text-growth-600 flex items-center gap-1">
              <TrendingUp size={14} />+{property.quickProjection.estimatedProfitPct}%
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
