import { Link, useLocation } from "react-router-dom";
import { Landmark, PlusCircle } from "lucide-react";

export default function Navbar() {
  const location = useLocation();

  return (
    <header className="sticky top-0 z-40 bg-blueprint-900/95 backdrop-blur border-b border-blueprint-700 text-paper">
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <Landmark className="text-brass-500 group-hover:rotate-6 transition-transform duration-300" size={24} />
          <span className="flex items-baseline gap-2">
            <span className="font-display text-2xl tracking-tight">Bhoomi</span>
            <span className="hidden md:inline text-[11px] uppercase tracking-[0.2em] text-brass-400 font-semibold">
              A New Era of Investing &amp; Selling
            </span>
          </span>
        </Link>
        <nav className="flex items-center gap-3 sm:gap-6 text-sm font-medium">
          <Link
            to="/"
            className={`hidden sm:inline hover:text-brass-400 transition-colors ${
              location.pathname === "/" ? "text-brass-400" : ""
            }`}
          >
            Search
          </Link>
          <a href="/#how-it-works" className="hidden sm:inline hover:text-brass-400 transition-colors">
            How it works
          </a>
          <Link
            to="/list-property"
            className="flex items-center gap-1.5 bg-brass-500 hover:bg-brass-400 text-blueprint-950 font-semibold rounded-full px-4 py-2 transition-colors"
          >
            <PlusCircle size={16} />
            <span>List a Property</span>
          </Link>
        </nav>
      </div>
    </header>
  );
}
