const BASE_URL = "http://localhost:5000/api";

export async function fetchMeta() {
  const res = await fetch(`${BASE_URL}/meta`);
  if (!res.ok) throw new Error("Failed to load filters");
  return res.json();
}

export async function searchProperties(filters) {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      params.append(key, value);
    }
  });
  const res = await fetch(`${BASE_URL}/properties?${params.toString()}`);
  if (!res.ok) throw new Error("Failed to search properties");
  return res.json();
}

export async function fetchPropertyDetail(id) {
  const res = await fetch(`${BASE_URL}/properties/${id}`);
  if (!res.ok) throw new Error("Property not found");
  return res.json();
}

export async function fetchAreaProfile(city, area) {
  const params = new URLSearchParams({ city: city || "", area: area || "" });
  const res = await fetch(`${BASE_URL}/area-profile?${params.toString()}`);
  if (!res.ok) throw new Error("Failed to load area profile");
  return res.json();
}

export async function createProperty(payload) {
  const res = await fetch(`${BASE_URL}/properties`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to create listing");
  }
  return res.json();
}
