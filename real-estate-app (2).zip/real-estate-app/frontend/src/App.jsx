import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import HomePage from "./pages/HomePage.jsx";
import PropertyDetailPage from "./pages/PropertyDetailPage.jsx";
import ListPropertyPage from "./pages/ListPropertyPage.jsx";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/property/:id" element={<PropertyDetailPage />} />
          <Route path="/list-property" element={<ListPropertyPage />} />
        </Routes>
      </main>
      <footer className="bg-blueprint-950 text-blueprint-100 text-center text-xs py-6">
        Bhoomi — A New Era of Investing &amp; Selling. Demo project with sample data. Built for local development.
      </footer>
    </div>
  );
}
