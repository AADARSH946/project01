# Bhoomi — A New Era of Investing & Selling

A full-stack demo web app: search Indian residential properties by city,
locality and budget, and see an estimated future value, a suggested year
to sell, and nearby infrastructure (metro/highway projects, hospitals,
schools, road connectivity).

**This ships with realistic sample data for 8 cities (Ahmedabad, Mumbai,
Pune, Bangalore, Hyderabad, Delhi NCR / Noida-Gurugram, Kolkata, Chennai) —
it is not connected to a live property listings feed.** See "Going further"
below for how to plug in real data.

Of the 39 properties included, 10 are adapted from a public Kaggle dataset
— see "Kaggle-sourced properties" below — and are marked with a **"Kaggle
Dataset" watermark** in the UI so their provenance is always visible.

---

## Project structure

```
real-estate-app/
  backend/          Node + Express API, serves property data & profit calculations
  frontend/         React + Vite + Tailwind website
```

## Prerequisites

- **Node.js 18+** and npm installed. Check with:
  ```
  node -v
  npm -v
  ```
  If you don't have it, download from https://nodejs.org (LTS version).

## How to run it (2 terminals in VS Code)

### 1. Start the backend

Open a terminal in VS Code (`` Ctrl+` ``):

```bash
cd real-estate-app/backend
npm install
npm start
```

You should see: `Backend running on http://localhost:5000`

Leave this terminal running. Test it worked by opening
http://localhost:5000/api/meta in a browser — you should see JSON.

### 2. Start the frontend

Open a **second** terminal (click the `+` in the VS Code terminal panel):

```bash
cd real-estate-app/frontend
npm install
npm run dev
```

You should see a local URL, typically `http://localhost:5173`.
Open that in your browser — that's the website.

Both servers need to stay running at the same time while you use the site.

---

## What it does

- **Search**: filter properties by city, locality, property type, BHK, and
  max budget.
- **Results grid**: each card shows a quick 5-year profit estimate.
- **Property detail page**:
  - 10-year value projection chart
  - A suggested sell year with reasoning
  - Nearby upcoming infrastructure projects (metro, highway, IT parks, etc.)
  - Nearby hospitals, schools, and road connectivity
- **List a Property** (`/list-property`): submit your own property. As you
  type in a city/locality, a live preview shows the nearby infrastructure
  (projects, hospitals, schools, roads) that will be attached automatically,
  matched from properties already known in that locality — falling back to
  city-wide data, or a plain "no data yet" note, if there's no exact match.
  Listings you add are saved to `backend/data/user-listings.json` so they
  persist across restarts, and immediately show up in search results and
  get their own 10-year projection + sell-year recommendation.

## How the profit / sell-year estimate works

This is a **transparent rule-based heuristic**, not a trained ML model and
not financial advice — see `backend/utils/profitCalculator.js`:

1. Every property has a base annual appreciation rate for its locality
   (from historical trend, stored in the sample data).
2. Nearby infrastructure projects (metro, highway, airport, IT park, etc.)
   add a temporary "boost" to that rate in the ~1 year before and 2 years
   after their completion date, weighted by how close they are.
3. Value is compounded year-by-year for a 10-year horizon using the
   effective rate for each year.
4. The suggested sell year is the year right after the **last** major
   nearby catalyst finishes playing out — i.e. when growth is expected to
   settle back to the locality's baseline rate.

You can tune the boost weights, decay distance, and time windows at the
top of `profitCalculator.js`.

## Kaggle-sourced properties

10 of the 39 sample properties (`KAG001`–`KAG010` in
`backend/data/properties.js`) have their title, city, locality, price,
size and BHK adapted from the public Kaggle dataset **"Housing Prices in
Metropolitan Areas of India"** by ruchi798
(kaggle.com/datasets/ruchi798/housing-prices-in-metropolitan-areas-of-india).
That dataset doesn't include appreciation rate or nearby-infrastructure
data, so those two fields are supplemented the same way as the rest of
this file's sample data.

Each of these properties carries `source: "kaggle"` and a `sourceDataset`
string. The frontend uses that flag to show:
- a subtle diagonal **"Kaggle" watermark** across the property photo
- a small **"Kaggle Dataset"** badge on the card and detail page
- an attribution line on the detail page naming the dataset

To mark any property you add yourself as sourced from a dataset, just add
`source: "kaggle"` (or your own source label) and a `sourceDataset` string
to its entry in `properties.js` — the watermark logic keys off that field
alone, so it works for future data sources too.

## Going further (replacing sample data with real data)

To make this production-real, you'd swap `backend/data/properties.js` for
a real data source, for example:
- A scraper or licensed data feed from 99acres / MagicBricks / Housing.com
- Government open data (e.g. RERA project registries, state land record
  portals) for verified project status and possession dates
- A proper database (Postgres/MongoDB) instead of an in-memory array, with
  the same shape of fields the frontend already expects
- A real appreciation-rate dataset per locality (e.g. from registered
  transaction/registry data) instead of the illustrative rates used here

The frontend and API contract won't need to change much — just the data
source behind `GET /api/properties` and `GET /api/properties/:id`.

## Tech stack

- **Backend**: Node.js, Express
- **Frontend**: React 18, Vite, Tailwind CSS, React Router, Recharts
- **Data**: in-memory sample dataset (no database required to run this demo)
