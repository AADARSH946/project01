// Mock dataset representing Indian residential properties.
// Replace this with a real data source (MagicBricks/99acres API, scraped data,
// or your own DB) when you're ready to go beyond the demo.

const properties = [
  {
    id: "AHM001",
    title: "Shivalik Sky Residency",
    city: "Ahmedabad",
    area: "South Bopal",
    address: "Near South Bopal Circle, Ahmedabad",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1650,
    price: 8500000,
    pricePerSqft: 5151,
    status: "Ready to Move",
    launchedYear: 2021,
    possessionYear: 2023,
    appreciationRate: 8.5,
    image: "https://picsum.photos/seed/AHM001/640/420",
    amenities: ["Clubhouse", "Swimming Pool", "Gym", "24x7 Security", "Kids Play Area"],
    nearbyProjects: [
      { name: "SP Ring Road Widening", type: "Road Infrastructure", distanceKm: 2.1, completionYear: 2027, status: "Under Construction" },
      { name: "South Bopal IT Park", type: "Commercial/IT", distanceKm: 3.4, completionYear: 2028, status: "Planned" },
      { name: "Metro Phase 2 Extension", type: "Metro", distanceKm: 4.0, completionYear: 2029, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Zydus Hospital", distanceKm: 3.2 },
      { name: "SAL Hospital", distanceKm: 4.8 }
    ],
    schools: [
      { name: "Udgam School for Children", distanceKm: 1.5 },
      { name: "Anand Niketan School", distanceKm: 2.8 }
    ],
    roadConnectivity: [
      { name: "SP Ring Road", distanceKm: 1.8 },
      { name: "SG Highway", distanceKm: 3.5 }
    ]
  },
  {
    id: "AHM002",
    title: "Godrej Garden City Phase 3",
    city: "Ahmedabad",
    area: "Jagatpur",
    address: "Jagatpur, Off SG Highway, Ahmedabad",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1180,
    price: 5600000,
    pricePerSqft: 4745,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2026,
    appreciationRate: 10.2,
    image: "https://picsum.photos/seed/AHM002/640/420",
    amenities: ["Clubhouse", "Jogging Track", "Amphitheatre", "Security"],
    nearbyProjects: [
      { name: "Jagatpur-Gandhinagar Highway Expansion", type: "Road Infrastructure", distanceKm: 1.2, completionYear: 2026, status: "Under Construction" },
      { name: "GIFT City Extension", type: "Commercial/Financial Hub", distanceKm: 6.5, completionYear: 2028, status: "Under Construction" }
    ],
    hospitals: [
      { name: "CIMS Hospital", distanceKm: 5.0 }
    ],
    schools: [
      { name: "Delhi Public School Bopal", distanceKm: 4.2 }
    ],
    roadConnectivity: [
      { name: "SG Highway", distanceKm: 1.0 },
      { name: "SP Ring Road", distanceKm: 5.5 }
    ]
  },
  {
    id: "AHM003",
    title: "Sun South Park",
    city: "Ahmedabad",
    area: "Vaishnodevi Circle",
    address: "Vaishnodevi Circle, SG Highway, Ahmedabad",
    type: "Apartment",
    bhk: 4,
    sizeSqft: 2200,
    price: 13500000,
    pricePerSqft: 6136,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 7.8,
    image: "https://picsum.photos/seed/AHM003/640/420",
    amenities: ["Rooftop Garden", "Gym", "Clubhouse", "Power Backup"],
    nearbyProjects: [
      { name: "Vaishnodevi Flyover", type: "Road Infrastructure", distanceKm: 0.8, completionYear: 2025, status: "Under Construction" },
      { name: "Circle Mall Expansion", type: "Retail", distanceKm: 1.5, completionYear: 2026, status: "Planned" }
    ],
    hospitals: [
      { name: "Shalby Hospital", distanceKm: 3.9 }
    ],
    schools: [
      { name: "Zebar International School", distanceKm: 2.0 }
    ],
    roadConnectivity: [
      { name: "SG Highway", distanceKm: 0.5 }
    ]
  },
  {
    id: "PUN001",
    title: "Kolte Patil Life Republic",
    city: "Pune",
    area: "Hinjewadi",
    address: "Marunji Road, Hinjewadi, Pune",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 980,
    price: 7200000,
    pricePerSqft: 7346,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2022,
    appreciationRate: 9.4,
    image: "https://picsum.photos/seed/PUN001/640/420",
    amenities: ["Clubhouse", "Swimming Pool", "Gym", "Co-working Lounge"],
    nearbyProjects: [
      { name: "Pune Metro Line 3 (Hinjewadi-Shivajinagar)", type: "Metro", distanceKm: 1.0, completionYear: 2026, status: "Under Construction" },
      { name: "Hinjewadi Phase 3 IT Park Expansion", type: "Commercial/IT", distanceKm: 2.5, completionYear: 2027, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Aditya Birla Memorial Hospital", distanceKm: 4.5 },
      { name: "Lifepoint Hospital", distanceKm: 2.2 }
    ],
    schools: [
      { name: "Podar International School", distanceKm: 1.8 }
    ],
    roadConnectivity: [
      { name: "Mumbai-Bangalore Highway (NH48)", distanceKm: 2.0 },
      { name: "Hinjewadi-Wakad Road", distanceKm: 0.9 }
    ]
  },
  {
    id: "PUN002",
    title: "Godrej Woodsville",
    city: "Pune",
    area: "Mahalunge",
    address: "Mahalunge, Near Balewadi, Pune",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1420,
    price: 11800000,
    pricePerSqft: 8310,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2027,
    appreciationRate: 11.1,
    image: "https://picsum.photos/seed/PUN002/640/420",
    amenities: ["Rooftop Infinity Pool", "Sports Deck", "Clubhouse", "EV Charging"],
    nearbyProjects: [
      { name: "Balewadi High Street Extension", type: "Retail/Commercial", distanceKm: 2.0, completionYear: 2026, status: "Under Construction" },
      { name: "Pune Ring Road (West)", type: "Road Infrastructure", distanceKm: 3.1, completionYear: 2028, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Sahyadri Hospital Balewadi", distanceKm: 2.8 }
    ],
    schools: [
      { name: "Vibgyor High", distanceKm: 1.9 }
    ],
    roadConnectivity: [
      { name: "Baner-Pashan Link Road", distanceKm: 1.4 }
    ]
  },
  {
    id: "BLR001",
    title: "Prestige Lakeside Habitat",
    city: "Bangalore",
    area: "Varthur",
    address: "Whitefield-Varthur Road, Bangalore",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1580,
    price: 15200000,
    pricePerSqft: 9620,
    status: "Ready to Move",
    launchedYear: 2018,
    possessionYear: 2021,
    appreciationRate: 8.9,
    image: "https://picsum.photos/seed/BLR001/640/420",
    amenities: ["Lake View", "Clubhouse", "Multiple Pools", "Tennis Court"],
    nearbyProjects: [
      { name: "Whitefield Metro (Purple Line)", type: "Metro", distanceKm: 3.5, completionYear: 2025, status: "Near Completion" },
      { name: "ITPL Road Widening", type: "Road Infrastructure", distanceKm: 2.8, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Columbia Asia Hospital Whitefield", distanceKm: 3.0 }
    ],
    schools: [
      { name: "Vydehi School of Excellence", distanceKm: 2.5 }
    ],
    roadConnectivity: [
      { name: "Outer Ring Road", distanceKm: 4.0 },
      { name: "Varthur Main Road", distanceKm: 0.6 }
    ]
  },
  {
    id: "BLR002",
    title: "Sobha Neopolis",
    city: "Bangalore",
    area: "Panathur",
    address: "Panathur Main Road, Bangalore",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1240,
    price: 12600000,
    pricePerSqft: 10161,
    status: "Under Construction",
    launchedYear: 2022,
    possessionYear: 2026,
    appreciationRate: 10.8,
    image: "https://picsum.photos/seed/BLR002/640/420",
    amenities: ["Sky Garden", "Gym", "Clubhouse", "Co-working Space"],
    nearbyProjects: [
      { name: "Sarjapur-Panathur Elevated Corridor", type: "Road Infrastructure", distanceKm: 1.5, completionYear: 2027, status: "Under Construction" },
      { name: "Panathur Tech Park", type: "Commercial/IT", distanceKm: 1.0, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Cloudnine Hospital Sarjapur Road", distanceKm: 3.6 }
    ],
    schools: [
      { name: "Greenwood High International", distanceKm: 2.1 }
    ],
    roadConnectivity: [
      { name: "Sarjapur Road", distanceKm: 1.2 },
      { name: "Outer Ring Road", distanceKm: 5.0 }
    ]
  },
  {
    id: "HYD001",
    title: "My Home Bhooja",
    city: "Hyderabad",
    area: "Kokapet",
    address: "Financial District, Kokapet, Hyderabad",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1780,
    price: 14500000,
    pricePerSqft: 8146,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2023,
    appreciationRate: 12.3,
    image: "https://picsum.photos/seed/HYD001/640/420",
    amenities: ["Clubhouse", "Infinity Pool", "Indoor Games", "Landscaped Gardens"],
    nearbyProjects: [
      { name: "Kokapet Neopolis Financial District", type: "Commercial/Financial Hub", distanceKm: 1.5, completionYear: 2027, status: "Under Construction" },
      { name: "Outer Ring Road - Kokapet Interchange", type: "Road Infrastructure", distanceKm: 2.0, completionYear: 2026, status: "Under Construction" },
      { name: "Metro Rail Extension to Kokapet", type: "Metro", distanceKm: 3.0, completionYear: 2028, status: "Planned" }
    ],
    hospitals: [
      { name: "Continental Hospitals", distanceKm: 4.2 }
    ],
    schools: [
      { name: "Oakridge International School", distanceKm: 3.0 }
    ],
    roadConnectivity: [
      { name: "Outer Ring Road", distanceKm: 1.8 },
      { name: "Nehru Outer Ring Road", distanceKm: 1.8 }
    ]
  },
  {
    id: "HYD002",
    title: "Aparna Sarovar Zenith",
    city: "Hyderabad",
    area: "Nallagandla",
    address: "Nallagandla, Serilingampally, Hyderabad",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1150,
    price: 7800000,
    pricePerSqft: 6783,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2022,
    appreciationRate: 9.6,
    image: "https://picsum.photos/seed/HYD002/640/420",
    amenities: ["Clubhouse", "Gym", "Swimming Pool", "24x7 Security"],
    nearbyProjects: [
      { name: "Nallagandla-Gachibowli Road Upgrade", type: "Road Infrastructure", distanceKm: 1.8, completionYear: 2025, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Sunshine Hospital Gachibowli", distanceKm: 5.0 }
    ],
    schools: [
      { name: "DPS Nacharam Annexe", distanceKm: 2.4 }
    ],
    roadConnectivity: [
      { name: "Nallagandla Road", distanceKm: 0.5 },
      { name: "Outer Ring Road", distanceKm: 3.5 }
    ]
  },
  {
    id: "MUM001",
    title: "Lodha Codename Amazing",
    city: "Mumbai",
    area: "Thane West",
    address: "Ghodbunder Road, Thane West, Mumbai",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 720,
    price: 11500000,
    pricePerSqft: 15972,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2027,
    appreciationRate: 9.8,
    image: "https://picsum.photos/seed/MUM001/640/420",
    amenities: ["Sky Deck", "Clubhouse", "Gym", "Kids Play Area"],
    nearbyProjects: [
      { name: "Thane Metro Line 4", type: "Metro", distanceKm: 2.0, completionYear: 2026, status: "Under Construction" },
      { name: "Ghodbunder Road Widening", type: "Road Infrastructure", distanceKm: 0.5, completionYear: 2025, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Jupiter Hospital Thane", distanceKm: 3.5 }
    ],
    schools: [
      { name: "Singapore International School", distanceKm: 2.2 }
    ],
    roadConnectivity: [
      { name: "Ghodbunder Road", distanceKm: 0.3 },
      { name: "Eastern Express Highway", distanceKm: 6.0 }
    ]
  },
  {
    id: "MUM002",
    title: "Runwal Bliss",
    city: "Mumbai",
    area: "Kanjurmarg",
    address: "LBS Marg, Kanjurmarg West, Mumbai",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 980,
    price: 21500000,
    pricePerSqft: 21939,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2022,
    appreciationRate: 7.5,
    image: "https://picsum.photos/seed/MUM002/640/420",
    amenities: ["Clubhouse", "Swimming Pool", "Gym", "Amphitheatre"],
    nearbyProjects: [
      { name: "Metro Line 6 Kanjurmarg Depot", type: "Metro", distanceKm: 1.2, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Fortis Hospital Mulund", distanceKm: 4.0 }
    ],
    schools: [
      { name: "Ryan International School", distanceKm: 1.5 }
    ],
    roadConnectivity: [
      { name: "LBS Marg", distanceKm: 0.2 },
      { name: "Eastern Express Highway", distanceKm: 3.0 }
    ]
  },
  {
    id: "DEL001",
    title: "ATS Kocoon",
    city: "Delhi NCR",
    area: "Sector 152, Noida",
    address: "Sector 152, Noida Expressway, Delhi NCR",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1650,
    price: 14200000,
    pricePerSqft: 8606,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2023,
    appreciationRate: 13.5,
    image: "https://picsum.photos/seed/DEL001/640/420",
    amenities: ["Clubhouse", "Golf Putting Green", "Gym", "Jogging Track"],
    nearbyProjects: [
      { name: "Noida International Airport (Jewar)", type: "Airport", distanceKm: 25, completionYear: 2026, status: "Under Construction" },
      { name: "Noida Metro Aqua Line Extension", type: "Metro", distanceKm: 4.0, completionYear: 2027, status: "Planned" },
      { name: "Noida Expressway Widening", type: "Road Infrastructure", distanceKm: 1.0, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Yatharth Hospital", distanceKm: 3.0 }
    ],
    schools: [
      { name: "Lotus Valley International School", distanceKm: 2.5 }
    ],
    roadConnectivity: [
      { name: "Noida-Greater Noida Expressway", distanceKm: 0.8 }
    ]
  },
  {
    id: "DEL002",
    title: "M3M Golf Estate",
    city: "Delhi NCR",
    area: "Sector 65, Gurugram",
    address: "Golf Course Extension Road, Gurugram",
    type: "Apartment",
    bhk: 4,
    sizeSqft: 2450,
    price: 32000000,
    pricePerSqft: 13061,
    status: "Ready to Move",
    launchedYear: 2018,
    possessionYear: 2021,
    appreciationRate: 10.9,
    image: "https://picsum.photos/seed/DEL002/640/420",
    amenities: ["Golf Course View", "Clubhouse", "Infinity Pool", "Concierge"],
    nearbyProjects: [
      { name: "Golf Course Extension Road Widening", type: "Road Infrastructure", distanceKm: 0.5, completionYear: 2025, status: "Under Construction" },
      { name: "Gurugram Metro Extension", type: "Metro", distanceKm: 3.2, completionYear: 2028, status: "Planned" }
    ],
    hospitals: [
      { name: "Medanta - The Medicity", distanceKm: 6.0 },
      { name: "Artemis Hospital", distanceKm: 5.4 }
    ],
    schools: [
      { name: "Heritage Xperiential School", distanceKm: 2.0 }
    ],
    roadConnectivity: [
      { name: "Golf Course Extension Road", distanceKm: 0.4 },
      { name: "NH48", distanceKm: 7.0 }
    ]
  },
  {
    id: "AHM004",
    title: "Arvind Skyline",
    city: "Ahmedabad",
    area: "Shela",
    address: "Shela, S.P. Ring Road, Ahmedabad",
    type: "Villa",
    bhk: 4,
    sizeSqft: 3200,
    price: 21000000,
    pricePerSqft: 6563,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2022,
    appreciationRate: 8.1,
    image: "https://picsum.photos/seed/AHM004/640/420",
    amenities: ["Private Garden", "Clubhouse", "Gated Community", "Security"],
    nearbyProjects: [
      { name: "Shela-Bopal Road Upgrade", type: "Road Infrastructure", distanceKm: 1.6, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Sterling Hospital", distanceKm: 5.5 }
    ],
    schools: [
      { name: "Global Indian International School", distanceKm: 3.2 }
    ],
    roadConnectivity: [
      { name: "SP Ring Road", distanceKm: 1.0 }
    ]
  },
  {
    id: "PUN003",
    title: "Rohan Ananta",
    city: "Pune",
    area: "Undri",
    address: "NIBM Road, Undri, Pune",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 950,
    price: 5900000,
    pricePerSqft: 6210,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2026,
    appreciationRate: 9.0,
    image: "https://picsum.photos/seed/PUN003/640/420",
    amenities: ["Clubhouse", "Gym", "Landscaped Garden"],
    nearbyProjects: [
      { name: "NIBM Road Widening", type: "Road Infrastructure", distanceKm: 1.0, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Noble Hospital", distanceKm: 4.8 }
    ],
    schools: [
      { name: "Vibgyor High Undri", distanceKm: 1.2 }
    ],
    roadConnectivity: [
      { name: "NIBM Road", distanceKm: 0.6 }
    ]
  },
  {
    id: "BLR003",
    title: "Brigade Cornerstone Utopia",
    city: "Bangalore",
    area: "Whitefield",
    address: "Varthur Road, Whitefield, Bangalore",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1680,
    price: 16800000,
    pricePerSqft: 10000,
    status: "Under Construction",
    launchedYear: 2022,
    possessionYear: 2027,
    appreciationRate: 9.9,
    image: "https://picsum.photos/seed/BLR003/640/420",
    amenities: ["25-Acre Township", "Clubhouse", "Multiple Pools", "Sports Arena"],
    nearbyProjects: [
      { name: "Whitefield Metro (Purple Line)", type: "Metro", distanceKm: 2.0, completionYear: 2025, status: "Near Completion" },
      { name: "ITPL-Varthur Road Upgrade", type: "Road Infrastructure", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Manipal Hospital Whitefield", distanceKm: 2.5 }
    ],
    schools: [
      { name: "Global Indian International School", distanceKm: 3.5 }
    ],
    roadConnectivity: [
      { name: "Varthur Road", distanceKm: 0.5 },
      { name: "Outer Ring Road", distanceKm: 6.0 }
    ]
  },
  {
    id: "HYD003",
    title: "Rajapushpa Atria",
    city: "Hyderabad",
    area: "Kokapet",
    address: "Narsingi-Kokapet Road, Hyderabad",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1920,
    price: 17500000,
    pricePerSqft: 9114,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2027,
    appreciationRate: 12.8,
    image: "https://picsum.photos/seed/HYD003/640/420",
    amenities: ["Sky Lounge", "Clubhouse", "Infinity Pool", "Gym"],
    nearbyProjects: [
      { name: "Kokapet Neopolis Financial District", type: "Commercial/Financial Hub", distanceKm: 0.9, completionYear: 2027, status: "Under Construction" },
      { name: "Outer Ring Road - Kokapet Interchange", type: "Road Infrastructure", distanceKm: 1.4, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Continental Hospitals", distanceKm: 3.5 }
    ],
    schools: [
      { name: "Oakridge International School", distanceKm: 2.4 }
    ],
    roadConnectivity: [
      { name: "Outer Ring Road", distanceKm: 1.2 }
    ]
  },
  {
    id: "AHM005",
    title: "Ganesh Glory 11",
    city: "Ahmedabad",
    area: "Jagatpur",
    address: "Jagatpur, Off SG Highway, Ahmedabad",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 620,
    price: 2800000,
    pricePerSqft: 4516,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 9.0,
    image: "https://picsum.photos/seed/AHM005/640/420",
    amenities: ["Gym", "Security", "Rooftop Garden"],
    nearbyProjects: [
      { name: "Jagatpur-Gandhinagar Highway Expansion", type: "Road Infrastructure", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" },
      { name: "GIFT City Extension", type: "Commercial/Financial Hub", distanceKm: 6.0, completionYear: 2028, status: "Under Construction" }
    ],
    hospitals: [
      { name: "CIMS Hospital", distanceKm: 5.2 }
    ],
    schools: [
      { name: "Delhi Public School Bopal", distanceKm: 4.5 }
    ],
    roadConnectivity: [
      { name: "SG Highway", distanceKm: 1.2 }
    ]
  },
  {
    id: "AHM006",
    title: "SGVP Green Acres Plot",
    city: "Ahmedabad",
    area: "Vaishnodevi Circle",
    address: "Near SGVP, Vaishnodevi Circle, Ahmedabad",
    type: "Plot",
    bhk: 0,
    sizeSqft: 2000,
    price: 6500000,
    pricePerSqft: 3250,
    status: "Ready to Move",
    launchedYear: 2022,
    possessionYear: 2022,
    appreciationRate: 11.5,
    image: "https://picsum.photos/seed/AHM006/640/420",
    amenities: ["Gated Layout", "Internal Roads", "Boundary Wall"],
    nearbyProjects: [
      { name: "Vaishnodevi Flyover", type: "Road Infrastructure", distanceKm: 1.0, completionYear: 2025, status: "Under Construction" },
      { name: "Circle Mall Expansion", type: "Retail", distanceKm: 1.8, completionYear: 2026, status: "Planned" }
    ],
    hospitals: [
      { name: "Shalby Hospital", distanceKm: 4.2 }
    ],
    schools: [
      { name: "Zebar International School", distanceKm: 2.5 }
    ],
    roadConnectivity: [
      { name: "SG Highway", distanceKm: 0.8 }
    ]
  },
  {
    id: "PUN004",
    title: "Rohan Abhilasha Plots",
    city: "Pune",
    area: "Undri",
    address: "NIBM Annexe, Undri, Pune",
    type: "Plot",
    bhk: 0,
    sizeSqft: 1800,
    price: 5400000,
    pricePerSqft: 3000,
    status: "Ready to Move",
    launchedYear: 2021,
    possessionYear: 2021,
    appreciationRate: 9.8,
    image: "https://picsum.photos/seed/PUN004/640/420",
    amenities: ["Gated Layout", "Underground Wiring", "Landscaped Entrance"],
    nearbyProjects: [
      { name: "NIBM Road Widening", type: "Road Infrastructure", distanceKm: 1.4, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Noble Hospital", distanceKm: 5.2 }
    ],
    schools: [
      { name: "Vibgyor High Undri", distanceKm: 1.6 }
    ],
    roadConnectivity: [
      { name: "NIBM Road", distanceKm: 1.0 }
    ]
  },
  {
    id: "PUN005",
    title: "Kumar Prospera Studio",
    city: "Pune",
    area: "Hinjewadi",
    address: "Phase 1, Hinjewadi, Pune",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 540,
    price: 3900000,
    pricePerSqft: 7222,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2021,
    appreciationRate: 8.7,
    image: "https://picsum.photos/seed/PUN005/640/420",
    amenities: ["Gym", "Co-working Lounge", "Security"],
    nearbyProjects: [
      { name: "Pune Metro Line 3 (Hinjewadi-Shivajinagar)", type: "Metro", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Lifepoint Hospital", distanceKm: 2.6 }
    ],
    schools: [
      { name: "Podar International School", distanceKm: 2.0 }
    ],
    roadConnectivity: [
      { name: "Mumbai-Bangalore Highway (NH48)", distanceKm: 2.4 }
    ]
  },
  {
    id: "BLR004",
    title: "Casagrand Independent Villa",
    city: "Bangalore",
    area: "Varthur",
    address: "Off Varthur Main Road, Bangalore",
    type: "Independent House",
    bhk: 4,
    sizeSqft: 2800,
    price: 24500000,
    pricePerSqft: 8750,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 9.5,
    image: "https://picsum.photos/seed/BLR004/640/420",
    amenities: ["Private Terrace", "Parking for 2", "Gated Community"],
    nearbyProjects: [
      { name: "Whitefield Metro (Purple Line)", type: "Metro", distanceKm: 3.8, completionYear: 2025, status: "Near Completion" },
      { name: "ITPL Road Widening", type: "Road Infrastructure", distanceKm: 3.0, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Columbia Asia Hospital Whitefield", distanceKm: 3.5 }
    ],
    schools: [
      { name: "Vydehi School of Excellence", distanceKm: 2.8 }
    ],
    roadConnectivity: [
      { name: "Varthur Main Road", distanceKm: 0.4 }
    ]
  },
  {
    id: "BLR005",
    title: "Value Budget Studio Panathur",
    city: "Bangalore",
    area: "Panathur",
    address: "Panathur Main Road, Bangalore",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 610,
    price: 5200000,
    pricePerSqft: 8524,
    status: "Ready to Move",
    launchedYear: 2021,
    possessionYear: 2023,
    appreciationRate: 10.1,
    image: "https://picsum.photos/seed/BLR005/640/420",
    amenities: ["Gym", "Security", "Power Backup"],
    nearbyProjects: [
      { name: "Sarjapur-Panathur Elevated Corridor", type: "Road Infrastructure", distanceKm: 1.8, completionYear: 2027, status: "Under Construction" },
      { name: "Panathur Tech Park", type: "Commercial/IT", distanceKm: 1.2, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Cloudnine Hospital Sarjapur Road", distanceKm: 3.9 }
    ],
    schools: [
      { name: "Greenwood High International", distanceKm: 2.4 }
    ],
    roadConnectivity: [
      { name: "Sarjapur Road", distanceKm: 1.5 }
    ]
  },
  {
    id: "HYD004",
    title: "Aparna Cyber Commune Studio",
    city: "Hyderabad",
    area: "Nallagandla",
    address: "Nallagandla, Serilingampally, Hyderabad",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 580,
    price: 3400000,
    pricePerSqft: 5862,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 8.9,
    image: "https://picsum.photos/seed/HYD004/640/420",
    amenities: ["Gym", "Swimming Pool", "Security"],
    nearbyProjects: [
      { name: "Nallagandla-Gachibowli Road Upgrade", type: "Road Infrastructure", distanceKm: 2.1, completionYear: 2025, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Sunshine Hospital Gachibowli", distanceKm: 5.4 }
    ],
    schools: [
      { name: "DPS Nacharam Annexe", distanceKm: 2.8 }
    ],
    roadConnectivity: [
      { name: "Nallagandla Road", distanceKm: 0.7 }
    ]
  },
  {
    id: "HYD005",
    title: "Kalpataru Signature Villa",
    city: "Hyderabad",
    area: "Kokapet",
    address: "Kokapet, Financial District, Hyderabad",
    type: "Villa",
    bhk: 4,
    sizeSqft: 3400,
    price: 42000000,
    pricePerSqft: 12353,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2027,
    appreciationRate: 13.0,
    image: "https://picsum.photos/seed/HYD005/640/420",
    amenities: ["Private Pool", "Home Theatre", "Landscaped Garden", "Concierge"],
    nearbyProjects: [
      { name: "Kokapet Neopolis Financial District", type: "Commercial/Financial Hub", distanceKm: 1.0, completionYear: 2027, status: "Under Construction" },
      { name: "Outer Ring Road - Kokapet Interchange", type: "Road Infrastructure", distanceKm: 1.6, completionYear: 2026, status: "Under Construction" },
      { name: "Metro Rail Extension to Kokapet", type: "Metro", distanceKm: 2.8, completionYear: 2028, status: "Planned" }
    ],
    hospitals: [
      { name: "Continental Hospitals", distanceKm: 4.0 }
    ],
    schools: [
      { name: "Oakridge International School", distanceKm: 2.9 }
    ],
    roadConnectivity: [
      { name: "Outer Ring Road", distanceKm: 1.5 }
    ]
  },
  {
    id: "MUM003",
    title: "Raymond Ten X Habitat Studio",
    city: "Mumbai",
    area: "Thane West",
    address: "Ghodbunder Road, Thane West, Mumbai",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 430,
    price: 6800000,
    pricePerSqft: 15814,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2027,
    appreciationRate: 9.5,
    image: "https://picsum.photos/seed/MUM003/640/420",
    amenities: ["Clubhouse", "Gym", "Kids Play Area"],
    nearbyProjects: [
      { name: "Thane Metro Line 4", type: "Metro", distanceKm: 2.3, completionYear: 2026, status: "Under Construction" },
      { name: "Ghodbunder Road Widening", type: "Road Infrastructure", distanceKm: 0.8, completionYear: 2025, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Jupiter Hospital Thane", distanceKm: 3.8 }
    ],
    schools: [
      { name: "Singapore International School", distanceKm: 2.5 }
    ],
    roadConnectivity: [
      { name: "Ghodbunder Road", distanceKm: 0.5 }
    ]
  },
  {
    id: "MUM004",
    title: "Kanjurmarg Independent Bungalow",
    city: "Mumbai",
    area: "Kanjurmarg",
    address: "Off LBS Marg, Kanjurmarg West, Mumbai",
    type: "Independent House",
    bhk: 4,
    sizeSqft: 1600,
    price: 38000000,
    pricePerSqft: 23750,
    status: "Ready to Move",
    launchedYear: 2018,
    possessionYear: 2019,
    appreciationRate: 7.2,
    image: "https://picsum.photos/seed/MUM004/640/420",
    amenities: ["Private Parking", "Terrace Garden", "Security"],
    nearbyProjects: [
      { name: "Metro Line 6 Kanjurmarg Depot", type: "Metro", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Fortis Hospital Mulund", distanceKm: 4.3 }
    ],
    schools: [
      { name: "Ryan International School", distanceKm: 1.8 }
    ],
    roadConnectivity: [
      { name: "LBS Marg", distanceKm: 0.3 }
    ]
  },
  {
    id: "DEL003",
    title: "Sector 150 Independent Floor",
    city: "Delhi NCR",
    area: "Sector 152, Noida",
    address: "Sector 150, Noida Expressway, Delhi NCR",
    type: "Independent House",
    bhk: 3,
    sizeSqft: 1400,
    price: 12500000,
    pricePerSqft: 8929,
    status: "Ready to Move",
    launchedYear: 2021,
    possessionYear: 2022,
    appreciationRate: 12.9,
    image: "https://picsum.photos/seed/DEL003/640/420",
    amenities: ["Private Terrace", "Covered Parking", "Security"],
    nearbyProjects: [
      { name: "Noida International Airport (Jewar)", type: "Airport", distanceKm: 24, completionYear: 2026, status: "Under Construction" },
      { name: "Noida Expressway Widening", type: "Road Infrastructure", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Yatharth Hospital", distanceKm: 3.4 }
    ],
    schools: [
      { name: "Lotus Valley International School", distanceKm: 2.9 }
    ],
    roadConnectivity: [
      { name: "Noida-Greater Noida Expressway", distanceKm: 1.2 }
    ]
  },
  {
    id: "DEL004",
    title: "Signature Global Park Studio",
    city: "Delhi NCR",
    area: "Sector 65, Gurugram",
    address: "Golf Course Extension Road, Gurugram",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 480,
    price: 4800000,
    pricePerSqft: 10000,
    status: "Under Construction",
    launchedYear: 2024,
    possessionYear: 2027,
    appreciationRate: 11.5,
    image: "https://picsum.photos/seed/DEL004/640/420",
    amenities: ["Gym", "Clubhouse", "Security"],
    nearbyProjects: [
      { name: "Golf Course Extension Road Widening", type: "Road Infrastructure", distanceKm: 1.1, completionYear: 2025, status: "Under Construction" },
      { name: "Gurugram Metro Extension", type: "Metro", distanceKm: 3.8, completionYear: 2028, status: "Planned" }
    ],
    hospitals: [
      { name: "Artemis Hospital", distanceKm: 5.8 }
    ],
    schools: [
      { name: "Heritage Xperiential School", distanceKm: 2.4 }
    ],
    roadConnectivity: [
      { name: "Golf Course Extension Road", distanceKm: 0.9 }
    ]
  },

  // ---------------------------------------------------------------------
  // Kaggle-sourced properties
  // Base price, size, BHK, locality and city fields are adapted from the
  // public Kaggle dataset "Housing Prices in Metropolitan Areas of India"
  // (kaggle.com/datasets/ruchi798/housing-prices-in-metropolitan-areas-of-india).
  // That dataset doesn't include appreciation rate or nearby-infrastructure
  // data, so those fields are supplemented here using the same locality
  // research approach as the rest of this file. Every property below is
  // tagged source: "kaggle" so the UI can show a provenance watermark.
  // ---------------------------------------------------------------------
  {
    id: "KAG001",
    title: "Salt Lake Sector V Residency",
    city: "Kolkata",
    area: "Salt Lake Sector V",
    address: "Sector V, Salt Lake, Kolkata",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1450,
    price: 8700000,
    pricePerSqft: 6000,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2021,
    appreciationRate: 7.6,
    image: "https://picsum.photos/seed/KAG001/640/420",
    amenities: ["Clubhouse", "Gym", "Security", "Power Backup"],
    nearbyProjects: [
      { name: "Salt Lake-New Town Metro Extension", type: "Metro", distanceKm: 2.4, completionYear: 2027, status: "Under Construction" },
      { name: "Sector V IT Corridor Upgrade", type: "Commercial/IT", distanceKm: 1.2, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "AMRI Hospital Salt Lake", distanceKm: 2.8 }
    ],
    schools: [
      { name: "Salt Lake Point School", distanceKm: 1.6 }
    ],
    roadConnectivity: [
      { name: "VIP Road", distanceKm: 1.9 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG002",
    title: "New Town Eco Park View",
    city: "Kolkata",
    area: "New Town",
    address: "Action Area II, New Town, Kolkata",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1020,
    price: 5600000,
    pricePerSqft: 5490,
    status: "Under Construction",
    launchedYear: 2023,
    possessionYear: 2026,
    appreciationRate: 8.9,
    image: "https://picsum.photos/seed/KAG002/640/420",
    amenities: ["Landscaped Garden", "Clubhouse", "Gym"],
    nearbyProjects: [
      { name: "New Town Metro Extension", type: "Metro", distanceKm: 1.8, completionYear: 2027, status: "Under Construction" },
      { name: "Rajarhat IT Park Expansion", type: "Commercial/IT", distanceKm: 3.0, completionYear: 2028, status: "Planned" }
    ],
    hospitals: [
      { name: "Tata Medical Center", distanceKm: 2.5 }
    ],
    schools: [
      { name: "Delhi Public School Newtown", distanceKm: 2.0 }
    ],
    roadConnectivity: [
      { name: "Major Arterial Road", distanceKm: 0.9 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG003",
    title: "OMR Tech Corridor Apartment",
    city: "Chennai",
    area: "Sholinganallur",
    address: "Old Mahabalipuram Road, Sholinganallur, Chennai",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1100,
    price: 6800000,
    pricePerSqft: 6182,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 8.4,
    image: "https://picsum.photos/seed/KAG003/640/420",
    amenities: ["Gym", "Swimming Pool", "Security"],
    nearbyProjects: [
      { name: "OMR IT Corridor Expansion", type: "Commercial/IT", distanceKm: 1.5, completionYear: 2026, status: "Under Construction" },
      { name: "Chennai Metro Phase 2 (OMR)", type: "Metro", distanceKm: 3.2, completionYear: 2028, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Global Hospital Perumbakkam", distanceKm: 3.0 }
    ],
    schools: [
      { name: "Gateway International School", distanceKm: 2.1 }
    ],
    roadConnectivity: [
      { name: "OMR (Rajiv Gandhi Salai)", distanceKm: 0.5 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG004",
    title: "Anna Nagar Classic Flat",
    city: "Chennai",
    area: "Anna Nagar",
    address: "2nd Avenue, Anna Nagar, Chennai",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1550,
    price: 13500000,
    pricePerSqft: 8710,
    status: "Ready to Move",
    launchedYear: 2018,
    possessionYear: 2020,
    appreciationRate: 7.1,
    image: "https://picsum.photos/seed/KAG004/640/420",
    amenities: ["Covered Parking", "Security", "Power Backup"],
    nearbyProjects: [
      { name: "Anna Nagar Metro Station Upgrade", type: "Metro", distanceKm: 0.9, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Apollo Hospital Anna Nagar", distanceKm: 2.2 }
    ],
    schools: [
      { name: "Chinmaya Vidyalaya", distanceKm: 1.3 }
    ],
    roadConnectivity: [
      { name: "Inner Ring Road", distanceKm: 1.1 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG005",
    title: "Powai Lake View Apartment",
    city: "Mumbai",
    area: "Powai",
    address: "Central Avenue, Powai, Mumbai",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 850,
    price: 16500000,
    pricePerSqft: 19412,
    status: "Ready to Move",
    launchedYear: 2017,
    possessionYear: 2019,
    appreciationRate: 8.2,
    image: "https://picsum.photos/seed/KAG005/640/420",
    amenities: ["Clubhouse", "Swimming Pool", "Lake View", "Gym"],
    nearbyProjects: [
      { name: "Powai-Vikhroli Metro Extension", type: "Metro", distanceKm: 2.0, completionYear: 2027, status: "Planned" }
    ],
    hospitals: [
      { name: "Hiranandani Hospital", distanceKm: 1.8 }
    ],
    schools: [
      { name: "Hiranandani Foundation School", distanceKm: 1.2 }
    ],
    roadConnectivity: [
      { name: "Jogeshwari-Vikhroli Link Road", distanceKm: 1.5 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG006",
    title: "Andheri East Business Suite",
    city: "Mumbai",
    area: "Andheri East",
    address: "Marol, Andheri East, Mumbai",
    type: "Apartment",
    bhk: 1,
    sizeSqft: 560,
    price: 9800000,
    pricePerSqft: 17500,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2021,
    appreciationRate: 8.8,
    image: "https://picsum.photos/seed/KAG006/640/420",
    amenities: ["Gym", "Security", "Power Backup"],
    nearbyProjects: [
      { name: "Metro Line 7A (Airport Extension)", type: "Metro", distanceKm: 1.6, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Kokilaben Dhirubhai Ambani Hospital", distanceKm: 3.4 }
    ],
    schools: [
      { name: "Ryan International Andheri", distanceKm: 1.7 }
    ],
    roadConnectivity: [
      { name: "Western Express Highway", distanceKm: 1.0 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG007",
    title: "Electronic City Phase 1 Flat",
    city: "Bangalore",
    area: "Electronic City",
    address: "Phase 1, Electronic City, Bangalore",
    type: "Apartment",
    bhk: 2,
    sizeSqft: 1080,
    price: 5900000,
    pricePerSqft: 5463,
    status: "Ready to Move",
    launchedYear: 2020,
    possessionYear: 2022,
    appreciationRate: 9.3,
    image: "https://picsum.photos/seed/KAG007/640/420",
    amenities: ["Gym", "Clubhouse", "Security"],
    nearbyProjects: [
      { name: "Electronic City Metro Extension", type: "Metro", distanceKm: 2.2, completionYear: 2027, status: "Under Construction" },
      { name: "NICE Road Widening", type: "Road Infrastructure", distanceKm: 1.4, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Narayana Health City", distanceKm: 2.6 }
    ],
    schools: [
      { name: "Delhi Public School Electronic City", distanceKm: 1.9 }
    ],
    roadConnectivity: [
      { name: "Hosur Road (NH44)", distanceKm: 0.8 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG008",
    title: "Indiranagar Heritage Flat",
    city: "Bangalore",
    area: "Indiranagar",
    address: "12th Main, Indiranagar, Bangalore",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1620,
    price: 22500000,
    pricePerSqft: 13889,
    status: "Ready to Move",
    launchedYear: 2016,
    possessionYear: 2018,
    appreciationRate: 7.9,
    image: "https://picsum.photos/seed/KAG008/640/420",
    amenities: ["Covered Parking", "Security", "Rooftop Terrace"],
    nearbyProjects: [
      { name: "Purple Line Metro Upgrade", type: "Metro", distanceKm: 0.7, completionYear: 2026, status: "Near Completion" }
    ],
    hospitals: [
      { name: "Manipal Hospital Old Airport Road", distanceKm: 2.4 }
    ],
    schools: [
      { name: "Frank Anthony Public School", distanceKm: 1.5 }
    ],
    roadConnectivity: [
      { name: "100 Feet Road", distanceKm: 0.4 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG009",
    title: "Dwarka Sector 21 Apartment",
    city: "Delhi NCR",
    area: "Dwarka Sector 21",
    address: "Sector 21, Dwarka, Delhi NCR",
    type: "Apartment",
    bhk: 3,
    sizeSqft: 1380,
    price: 11200000,
    pricePerSqft: 8116,
    status: "Ready to Move",
    launchedYear: 2019,
    possessionYear: 2021,
    appreciationRate: 9.7,
    image: "https://picsum.photos/seed/KAG009/640/420",
    amenities: ["Clubhouse", "Gym", "Security", "Power Backup"],
    nearbyProjects: [
      { name: "Dwarka Expressway Completion", type: "Road Infrastructure", distanceKm: 2.0, completionYear: 2026, status: "Under Construction" },
      { name: "Airport Metro Link Upgrade", type: "Metro", distanceKm: 1.5, completionYear: 2027, status: "Planned" }
    ],
    hospitals: [
      { name: "Max Hospital Dwarka", distanceKm: 2.3 }
    ],
    schools: [
      { name: "Delhi Public School Dwarka", distanceKm: 1.4 }
    ],
    roadConnectivity: [
      { name: "Dwarka Expressway", distanceKm: 1.2 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  },
  {
    id: "KAG010",
    title: "Rajouri Garden Builder Floor",
    city: "Delhi NCR",
    area: "Rajouri Garden",
    address: "Main Market, Rajouri Garden, Delhi NCR",
    type: "Independent House",
    bhk: 3,
    sizeSqft: 1250,
    price: 15800000,
    pricePerSqft: 12640,
    status: "Ready to Move",
    launchedYear: 2017,
    possessionYear: 2018,
    appreciationRate: 7.4,
    image: "https://picsum.photos/seed/KAG010/640/420",
    amenities: ["Covered Parking", "Power Backup", "Security"],
    nearbyProjects: [
      { name: "Rajouri Garden Metro Interchange Upgrade", type: "Metro", distanceKm: 0.6, completionYear: 2026, status: "Under Construction" }
    ],
    hospitals: [
      { name: "Fortis Hospital Rajouri Garden", distanceKm: 1.9 }
    ],
    schools: [
      { name: "Guru Harkrishan Public School", distanceKm: 1.1 }
    ],
    roadConnectivity: [
      { name: "Ring Road", distanceKm: 1.3 }
    ],
    source: "kaggle",
    sourceDataset: "Housing Prices in Metropolitan Areas of India (Kaggle, ruchi798)"
  }
];

export default properties;
