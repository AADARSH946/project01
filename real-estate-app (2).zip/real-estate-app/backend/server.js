import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import baseProperties from "./data/properties.js";
import { calculateProfitProjection } from "./utils/profitCalculator.js";
import { buildAreaProfile, suggestAppreciationRate } from "./utils/areaProfile.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const USER_LISTINGS_PATH = path.join(__dirname, "data", "user-listings.json");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// -------- Persistence for user-submitted listings --------
function loadUserListings() {
  try {
    if (!fs.existsSync(USER_LISTINGS_PATH)) return [];
    const raw = fs.readFileSync(USER_LISTINGS_PATH, "utf-8");
    return raw.trim() ? JSON.parse(raw) : [];
  } catch (err) {
    console.error("Failed to read user-listings.json:", err.message);
    return [];
  }
}

function saveUserListings(listings) {
  fs.writeFileSync(USER_LISTINGS_PATH, JSON.stringify(listings, null, 2));
}

let userListings = loadUserListings();

function allProperties() {
  return [...baseProperties, ...userListings];
}

// -------- Helper --------
function toCr(rupees) {
  return rupees / 10000000;
}

function withProfitSummary(p, years = 5) {
  const { projections } = calculateProfitProjection(p, years);
  const target = projections[years - 1];
  return {
    ...p,
    quickProjection: {
      year: target.year,
      estimatedValue: target.projectedValue,
      estimatedProfitPct: target.profitPct
    }
  };
}

// -------- Routes --------

// Get list of cities & areas (for dropdowns) — includes any user-added ones
app.get("/api/meta", (req, res) => {
  const all = allProperties();
  const cities = [...new Set(all.map((p) => p.city))].sort();
  const areasByCity = {};
  cities.forEach((city) => {
    areasByCity[city] = [
      ...new Set(all.filter((p) => p.city === city).map((p) => p.area))
    ].sort();
  });
  const propertyTypes = [...new Set(all.map((p) => p.type))];
  res.json({ cities, areasByCity, propertyTypes });
});

// Preview nearby infrastructure for a city/area before submitting a listing
app.get("/api/area-profile", (req, res) => {
  const { city, area } = req.query;
  const profile = buildAreaProfile(allProperties(), city, area);
  const suggestedAppreciationRate = city ? suggestAppreciationRate(allProperties(), city) : null;
  res.json({ ...profile, suggestedAppreciationRate });
});

// Search / filter properties
app.get("/api/properties", (req, res) => {
  const { city, area, minBudget, maxBudget, type, bhk } = req.query;

  let results = allProperties();

  if (city) results = results.filter((p) => p.city.toLowerCase() === city.toLowerCase());
  if (area) results = results.filter((p) => p.area.toLowerCase().includes(area.toLowerCase()));
  if (type) results = results.filter((p) => p.type.toLowerCase() === type.toLowerCase());
  if (bhk) results = results.filter((p) => p.bhk === Number(bhk));
  if (minBudget) results = results.filter((p) => p.price >= Number(minBudget));
  if (maxBudget) results = results.filter((p) => p.price <= Number(maxBudget));

  const withSummary = results.map((p) => withProfitSummary(p, 5));

  res.json({ count: withSummary.length, results: withSummary });
});

// Get single property with full profit projection + nearby details
app.get("/api/properties/:id", (req, res) => {
  const property = allProperties().find((p) => p.id === req.params.id);
  if (!property) return res.status(404).json({ error: "Property not found" });

  const { projections, recommendation } = calculateProfitProjection(property, 10);

  res.json({
    ...property,
    priceInCr: Number(toCr(property.price).toFixed(2)),
    profitProjection: projections,
    sellRecommendation: recommendation
  });
});

// List a new property (submitted by the user)
app.post("/api/properties", (req, res) => {
  const {
    title,
    city,
    area,
    address,
    type,
    bhk,
    sizeSqft,
    price,
    status,
    image,
    amenities,
    appreciationRate
  } = req.body;

  if (!title || !city || !area || !type || !bhk || !sizeSqft || !price) {
    return res.status(400).json({
      error: "Missing required fields: title, city, area, type, bhk, sizeSqft, price"
    });
  }

  const all = allProperties();
  const profile = buildAreaProfile(all, city, area);
  const rate =
    appreciationRate && !isNaN(Number(appreciationRate))
      ? Number(appreciationRate)
      : suggestAppreciationRate(all, city);

  const newProperty = {
    id: `USR${Date.now()}`,
    title,
    city,
    area,
    address: address || `${area}, ${city}`,
    type,
    bhk: Number(bhk),
    sizeSqft: Number(sizeSqft),
    price: Number(price),
    pricePerSqft: Math.round(Number(price) / Number(sizeSqft)),
    status: status || "Ready to Move",
    launchedYear: new Date().getFullYear(),
    possessionYear: new Date().getFullYear(),
    appreciationRate: rate,
    image: image && image.trim() ? image.trim() : `https://picsum.photos/seed/${Date.now()}/640/420`,
    amenities: Array.isArray(amenities) && amenities.length > 0 ? amenities : ["Not specified"],
    nearbyProjects: profile.nearbyProjects,
    hospitals: profile.hospitals,
    schools: profile.schools,
    roadConnectivity: profile.roadConnectivity,
    nearbyDataMatchType: profile.matchType, // "exact" | "city-wide" | "none"
    userListed: true
  };

  userListings.push(newProperty);
  saveUserListings(userListings);

  const { projections, recommendation } = calculateProfitProjection(newProperty, 10);

  res.status(201).json({
    ...newProperty,
    priceInCr: Number(toCr(newProperty.price).toFixed(2)),
    profitProjection: projections,
    sellRecommendation: recommendation
  });
});

app.get("/", (req, res) => {
  res.send("India Real Estate Investment Finder API is running.");
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
