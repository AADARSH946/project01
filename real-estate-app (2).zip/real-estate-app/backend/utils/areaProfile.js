// Builds a "what's nearby" profile (upcoming projects, hospitals, schools,
// road connectivity) for a given city + area, by looking at the properties
// we already know about in that same locality. This is what lets a newly
// listed property automatically inherit realistic nearby-infrastructure
// data instead of starting empty.
//
// Matching strategy, in order of preference:
//   1. Exact city + area match -> merge & dedupe from all matching listings
//   2. Same city, any area     -> merge & dedupe city-wide (marked approximate)
//   3. No match at all         -> empty profile, caller should say so

function dedupeByName(items) {
  const seen = new Map();
  for (const item of items) {
    if (!seen.has(item.name) || item.distanceKm < seen.get(item.name).distanceKm) {
      seen.set(item.name, item);
    }
  }
  return [...seen.values()].sort((a, b) => a.distanceKm - b.distanceKm);
}

export function buildAreaProfile(allProperties, city, area) {
  if (!city) {
    return {
      matchType: "none",
      nearbyProjects: [],
      hospitals: [],
      schools: [],
      roadConnectivity: []
    };
  }

  const cityMatches = allProperties.filter(
    (p) => p.city.toLowerCase() === city.toLowerCase()
  );

  const exactMatches = area
    ? cityMatches.filter((p) => p.area.toLowerCase() === area.toLowerCase())
    : [];

  const source = exactMatches.length > 0 ? exactMatches : cityMatches;
  const matchType = exactMatches.length > 0 ? "exact" : cityMatches.length > 0 ? "city-wide" : "none";

  return {
    matchType,
    nearbyProjects: dedupeByName(source.flatMap((p) => p.nearbyProjects || [])).slice(0, 6),
    hospitals: dedupeByName(source.flatMap((p) => p.hospitals || [])).slice(0, 5),
    schools: dedupeByName(source.flatMap((p) => p.schools || [])).slice(0, 5),
    roadConnectivity: dedupeByName(source.flatMap((p) => p.roadConnectivity || [])).slice(0, 5)
  };
}

export function suggestAppreciationRate(allProperties, city) {
  const cityMatches = allProperties.filter(
    (p) => p.city.toLowerCase() === city.toLowerCase()
  );
  if (cityMatches.length === 0) return 8.0; // generic India residential fallback
  const avg =
    cityMatches.reduce((sum, p) => sum + p.appreciationRate, 0) / cityMatches.length;
  return Number(avg.toFixed(1));
}
