// ------------------------------------------------------------------
// Profit / sell-timing model
//
// This is a transparent, rule-based heuristic (NOT a trained ML model
// and NOT financial advice). It is meant to give a directionally
// useful estimate you can refine later with real market data:
//
//   1. Every property has a base annual appreciation rate, taken from
//      its locality's historical trend (see properties.js).
//   2. Nearby infrastructure projects (metro, highway, IT park, airport,
//      etc.) typically cause a temporary "boost" to appreciation in the
//      2 years around their completion, because demand re-prices ahead
//      of and just after launch. Each project type has a boost weight.
//   3. We simulate value year-by-year for a 10 year horizon, applying
//      base rate + any active boosts for that year.
//   4. The "best time to sell" is estimated as the year immediately
//      after the last meaningful infra boost has fully played out,
//      since that's typically when the growth rate drops back to the
//      locality baseline (diminishing returns on holding longer).
// ------------------------------------------------------------------

const BOOST_WEIGHTS = {
  Metro: 3.0,
  Airport: 4.0,
  "Commercial/IT": 2.2,
  "Commercial/Financial Hub": 2.5,
  "Road Infrastructure": 1.4,
  Retail: 1.0
};

const BOOST_WINDOW_YEARS_BEFORE = 1; // anticipation effect
const BOOST_WINDOW_YEARS_AFTER = 2; // realization effect

function getActiveBoost(project, year) {
  const start = project.completionYear - BOOST_WINDOW_YEARS_BEFORE;
  const end = project.completionYear + BOOST_WINDOW_YEARS_AFTER;
  if (year < start || year > end) return 0;
  const weight = BOOST_WEIGHTS[project.type] || 1.0;
  // Distance decay: closer projects matter more (full effect within 2km, tapering to 0 by 10km)
  const distanceFactor = Math.max(0, 1 - project.distanceKm / 10);
  return weight * distanceFactor;
}

export function calculateProfitProjection(property, horizonYears = 10) {
  const currentYear = new Date().getFullYear();
  const projections = [];
  let value = property.price;
  let prevValue = property.price;

  for (let i = 1; i <= horizonYears; i++) {
    const year = currentYear + i;

    let boostTotal = 0;
    for (const project of property.nearbyProjects) {
      boostTotal += getActiveBoost(project, year);
    }

    const effectiveRate = property.appreciationRate + boostTotal;
    value = value * (1 + effectiveRate / 100);

    const yoyGrowthPct = ((value - prevValue) / prevValue) * 100;
    prevValue = value;

    projections.push({
      year,
      projectedValue: Math.round(value),
      effectiveAppreciationRate: Number(effectiveRate.toFixed(2)),
      yoyGrowthPct: Number(yoyGrowthPct.toFixed(2)),
      profitFromToday: Math.round(value - property.price),
      profitPct: Number((((value - property.price) / property.price) * 100).toFixed(2))
    });
  }

  const recommendation = recommendSellYear(property, projections, currentYear);

  return { projections, recommendation };
}

function recommendSellYear(property, projections, currentYear) {
  if (!property.nearbyProjects || property.nearbyProjects.length === 0) {
    // No catalysts nearby: recommend a standard 5-7 year hold for compounding.
    const target = projections.find((p) => p.year === currentYear + 6) || projections[projections.length - 1];
    return {
      suggestedYear: target.year,
      holdYears: target.year - currentYear,
      estimatedValue: target.projectedValue,
      estimatedProfit: target.profitFromToday,
      estimatedProfitPct: target.profitPct,
      reason:
        "No major infrastructure catalysts are mapped nearby, so the estimate assumes steady locality-level appreciation. A 5-7 year hold generally lets compounding work in your favor while covering registration/transaction costs."
    };
  }

  // Find the latest year any project's boost window ends
  const lastBoostEndYear = Math.max(
    ...property.nearbyProjects.map((p) => p.completionYear + BOOST_WINDOW_YEARS_AFTER)
  );

  const target =
    projections.find((p) => p.year === lastBoostEndYear) ||
    projections[projections.length - 1];

  const drivingProjects = property.nearbyProjects
    .filter((p) => p.completionYear + BOOST_WINDOW_YEARS_AFTER === lastBoostEndYear)
    .map((p) => p.name);

  return {
    suggestedYear: target.year,
    holdYears: target.year - currentYear,
    estimatedValue: target.projectedValue,
    estimatedProfit: target.profitFromToday,
    estimatedProfitPct: target.profitPct,
    reason: `Nearby catalyst${drivingProjects.length > 1 ? "s" : ""} (${drivingProjects.join(
      ", "
    )}) typically finish re-pricing demand about 2 years after completion. Holding until ${target.year} captures most of that infrastructure-driven upside before growth reverts to the locality's baseline rate.`
  };
}
